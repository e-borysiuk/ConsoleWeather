﻿namespace ConsoleDraw
{
    public enum DialogResult
    {
        OK,
        Cancel
    }
}