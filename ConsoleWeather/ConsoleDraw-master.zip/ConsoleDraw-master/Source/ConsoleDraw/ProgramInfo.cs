﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDraw
{
    static public class ProgramInfo
    {
        static public bool ExitProgram = false;

    }
}
